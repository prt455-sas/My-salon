﻿namespace MySalon_Master.Models
{
    public class Appointment
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public string Date { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MySalon_Master.Models
{
    public interface IEmailService
    {
        void Send(EmailMessage message);
    }
}
